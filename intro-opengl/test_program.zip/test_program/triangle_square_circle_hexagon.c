#include <math.h> 

#ifdef __APPLE__ 
    #include <OpenGL/gl.h> 
    #include <OpenGL/glu.h> 
    #include <GLUT/glut.h> 
#endif 
#ifdef __linux__ 
    #include <GL/glut.h> 
#endif 


//
// A general OpenGL initialization function.  Sets all of the initial parameters.
void InitGL (int width, int height)     // We call this right after our OpenGL window is created.
{
  glClearColor (0.0f, 0.0f, 0.0f, 0.0f); // This Will Clear The Background Color To Black
  glClearDepth (1.0);           // Enables Clearing Of The Depth Buffer
  glDepthFunc (GL_LESS);        // The Type Of Depth Test To Do
  glEnable (GL_DEPTH_TEST);     // Enables Depth Testing
  glShadeModel (GL_SMOOTH);     // Enables Smooth Color Shading
  glMatrixMode (GL_PROJECTION);
  glLoadIdentity ();            // Reset The Projection Matrix
  gluPerspective (45.0f, (GLfloat) width / (GLfloat) height, 0.1f, 100.0f); // Calculate The Aspect Ratio Of The Window
  glMatrixMode (GL_MODELVIEW);
}


void ReSizeGLScene (int width, int height)
{
  if (height == 0)                  // Prevent A Divide By Zero If The Window Is Too Small
  {
    height = 1;
  }
  glViewport (0, 0, width, height); // Reset The Current Viewport And Perspective Transformation
  glMatrixMode (GL_PROJECTION);
  glLoadIdentity ();
  gluPerspective (45.0f, (GLfloat) width / (GLfloat) height, 0.1f, 100.0f);
  glMatrixMode (GL_MODELVIEW);
}


void DrawGLScene ()
{
  float radius = 1.0;
  float circle_iterations = 24; // high values give a smoother circle approximation. Lower values give a course circle.
  float theta;

  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear The Screen And The Depth Buffer
  glLoadIdentity ();                                   // Reset The View

  glTranslatef (-1.5f, 1.0f, -6.0f);           // Move Left 1.5 Units And Into The Screen 6.0
//
// draw a RED triangle
  glColor3f (1.0, 0.0, 0.0); 
  glBegin (GL_POLYGON);           // start drawing a polygon
  glVertex3f ( 0.0f, 1.0f, 0.0f);    // Top
  glVertex3f ( 1.0f,-1.0f, 0.0f);   // Bottom Right
  glVertex3f (-1.0f,-1.0f, 0.0f);   // Bottom Left	
  glEnd ();                       // we're done with the polygon

  glTranslatef (0.0f, -2.5f, 0.0f);
//
// draw a GREEN square (quadrilateral)
  glColor3f (0.0, 1.0, 0.0); 
  glBegin (GL_QUADS);             // start drawing a polygon (4 sided)
  glVertex3f (-0.5f, 0.5f, 0.0f); // Top Left
  glVertex3f ( 0.5f, 0.5f, 0.0f); // Top Right
  glVertex3f ( 0.5f,-0.5f, 0.0f); // Bottom Right
  glVertex3f (-0.5f,-0.5f, 0.0f); // Bottom Left	
  glEnd ();                       // done with the polygon

  glTranslatef (3.0f, 2.5f, 0.0f);
//
// draw a BLUE circle approximated by triangles
  glColor3f (0.0, 0.0, 1.0); 
  glBegin (GL_POLYGON);
  for (theta = 0; theta < 2 * M_PI; theta += M_PI / circle_iterations)
  {
    glVertex3f (cos(theta) * radius, sin(theta) * radius, 0.0f);
  }
  glEnd();

  glTranslatef (0.0f, -2.5f, 0.0f);
//
// draw a YELLOW HEXAGON
  glColor3f (1.0f, 1.0f, 0.0f); 
  glBegin (GL_POLYGON);
  for (theta = 0.0f; theta < 2 * M_PI; theta += M_PI / 3.0f)
  {
    glVertex3f (cos(theta) * radius, sin(theta) * radius, 0.0f);
  }
  glEnd();

//
// swap buffers to display, since we're double buffered.
  glutSwapBuffers ();
}


int main (int argc, char *argv[]) 
{  
  int window;
//
// Initialize GLUT state - glut will take any command line arguments that pertain to it or X Windows.
// Look at its documentation at http://reality.sgi.com/mjk/spec3/spec3.html 
  glutInit (&argc, argv);  
//
// Select type of Display mode:   
//   * Double buffer 
//   * RGBA color
//   * Alpha components supported 
//   * Depth buffer
  glutInitDisplayMode (GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);  
//
// get a 640 x 480 window
  glutInitWindowSize (640, 480);
//
// the window starts at the upper left corner of the screen
  glutInitWindowPosition (0, 0);  
//
// Open a window
  window = glutCreateWindow ("triangle, square, circle, and hexagon");  
//
// Register the function to do all our OpenGL drawing.
  glutDisplayFunc (&DrawGLScene);  
//
// Even if there are no events, redraw our gl scene.
  glutIdleFunc (&DrawGLScene);
//
// Register the function called when our window is resized.
  glutReshapeFunc (&ReSizeGLScene);
//
// Initialize our window.
  InitGL (640, 480);
//  
// Start Event Processing Engine
  glutMainLoop ();  
//
// Exit success!
  return (0);
}













