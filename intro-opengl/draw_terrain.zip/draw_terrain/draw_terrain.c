#ifdef __APPLE__
  #include <OpenGL/gl.h>
  #include <OpenGL/glu.h>
  #include <GLUT/glut.h>
#elif __linux__
  #include <GL/glut.h>
#endif
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>


#define TRUE 1
#define FALSE 0
#define MAX_VERTICES_X 100
#define MAX_VERTICES_Z 100





GLfloat camera_position_x = 500.0f, camera_position_y = 30.0f, camera_position_z = 0.0f;
GLfloat center_x = 500.0f, center_y = 30.0f, center_z = -500.0f;
GLfloat terrain_height[MAX_VERTICES_X][MAX_VERTICES_Z];




void init (void)
{
  glShadeModel (GL_SMOOTH);
  glClearColor (1.0f, 1.0f, 1.0f, 0.0f);				
  glClearDepth (1.0f);
  glEnable (GL_DEPTH_TEST);
  glDepthFunc (GL_LEQUAL);
  glEnable (GL_COLOR_MATERIAL);
  glHint (GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
  glEnable (GL_LIGHTING);
  glEnable (GL_LIGHT0);
  GLfloat lightPos[4] = {-1.0, 1.0, 0.5, 0.0};
  glLightfv (GL_LIGHT0, GL_POSITION, (GLfloat *) &lightPos);
  glEnable (GL_LIGHT1);
  GLfloat lightAmbient1[4] = {0.1, 0.1,  0.1, 0.0};
  GLfloat lightPos1[4]     = {1.0, 0.0, -0.2, 0.0};
  GLfloat lightDiffuse1[4] = {0.5, 0.5,  0.5, 0.0};
  glLightfv (GL_LIGHT1,GL_POSITION, (GLfloat *) &lightPos1);
  glLightfv (GL_LIGHT1,GL_AMBIENT, (GLfloat *) &lightAmbient1);
  glLightfv (GL_LIGHT1,GL_DIFFUSE, (GLfloat *) &lightDiffuse1);
  glLightModeli (GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
}




void initialize_terrain_height (void)
{
  int index_x, index_z;
 
  for (index_z = 0; index_z < MAX_VERTICES_Z; index_z++)
  {
    for (index_x = 0; index_x < MAX_VERTICES_X; index_x++) 
    {
      terrain_height[index_x][index_z] = 0.0f;
    }
  }
}





void draw_terrain (void)
{
  GLfloat x, y, z;
  int index_x, index_z;

  glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
  glBegin(GL_TRIANGLES);
  z = -200.0f;
  for (index_z = 0; index_z < MAX_VERTICES_Z; index_z++)
  {
    x = -50.0f;
    for (index_x = 0; index_x < MAX_VERTICES_X; index_x++) 
    {
      y = terrain_height[index_x][index_z];
      glColor3ub (255, 255, 0);
      glVertex3f (x, y, z);
      glVertex3f (x + 10.0f, y, z);
      glVertex3f (x + 10.0f, y, z + 10.0f);
      glColor3ub (255, 255, 255);
      glVertex3f (x, y, z);
      glVertex3f (x, y, z + 10.0f);
      glVertex3f (x + 10.0f, y, z + 10.0f);
      x = x + 10.0f;
    }
    z = z + 10.0f;
  }
  glEnd();
  glFlush ();
}





void display (void)
{
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glLoadIdentity ();
  gluLookAt (camera_position_x, camera_position_y, camera_position_z, center_x, center_y, center_z, 0.0f, 1.0f, 0.0f);
  draw_terrain ();
  glutSwapBuffers();
  glutPostRedisplay();
}





void reshape (int w, int h)  
{
  glViewport (0, 0, w, h);
  glMatrixMode (GL_PROJECTION); 
  glLoadIdentity ();  
  if (h == 0)  
  { 
    gluPerspective (80, (float) w, 1.0, 5000.0);
  }
  else
  {
    gluPerspective (80, (float) w / (float) h, 1.0, 5000.0);
  }
  glMatrixMode (GL_MODELVIEW);  
  glLoadIdentity (); 
}





void arrow_keys (int key, int x, int y)
{
  switch (key)
  {
    case GLUT_KEY_UP:
      glutPostRedisplay ();
    break;
    case GLUT_KEY_DOWN:
      glutPostRedisplay ();
    break;
    case GLUT_KEY_LEFT:
      glutPostRedisplay ();
    break;
    case GLUT_KEY_RIGHT:
      glutPostRedisplay ();
    break;
    default:
    break;
  }
}





void keyboard (unsigned char key, int x, int y)
{
  switch (key)
  {
    case 27:
      exit (0);
    break;
    case 'a':
      glutPostRedisplay ();
    break;
    case 'z':
      glutPostRedisplay ();
    break;
    default:
    break;
  }
}





int main (int argc, char *argv[]) 
{
  int window;

  initialize_terrain_height();
  glutInit (&argc, argv);
  glutInitDisplayMode (GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);
  glutInitWindowSize (1280, 720); 
  glutInitWindowPosition (0, 0);
  window = glutCreateWindow ("Draw Terrain");
  init ();
  glutDisplayFunc (display);  
  glutReshapeFunc (reshape);
  glutSpecialFunc (arrow_keys);
  glutKeyboardFunc (keyboard);
  glutMainLoop ();
}

